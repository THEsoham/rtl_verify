# Cross-Family LLM Verification of Hardware RTL: An Empirical Study

**Authors:** Research Team  
**Date:** October 15, 2026  
**Artifact Repository:** `v2/final/`  
**Dataset & Total Observations:** $N = 211$ trials evaluated across 30 benchmark problems, 5 model pairs, 6 conditions, and 2 experimental arms.

---

## 1. Summary of Methodology and Findings

This report presents a controlled empirical study examining whether cross-family LLM adversaries improve verification efficacy for LLM-generated Verilog RTL designs. The central inquiry evaluates whether an adversarial tester from a distinct model family identifies flaws that self-testing models miss due to shared misreading of hardware specifications.

### Key Empirical Findings:
1. **Low Testbench Validity on Golden Reference Designs:** In the free-form testbench arm, models frequently synthesize testbenches that fail when simulated against the correct golden RTL design (Condition A wrong-test rate: 27 of 36, 75.0%). Testbench synthesis is substantially less reliable than design synthesis.
2. **Template Scaffolding Mitigates Contract and Syntax Failures:** In the template arm (where the framework provides clock, reset, module instantiations, and comparison assertions), testbench validity is N/A in Condition A ($n = 0$), confirming that harness boilerplate drives a major portion of free-form testbench invalidity.
3. **Shared Misreading Exceeds Cross-Family Agreement:** When two testbenches fail on the golden design, testbenches from the same model or model family make identical wrong first-assertions in 54.3% of pairs (507 of 933, 95% CI [51.2%, 57.6%]), whereas testbenches from different model families agree on the same wrong expectation in only 29.6% of pairs (245 of 828, 95% CI [26.4%, 32.7%]).
4. **Compute-Matched Self-Testing Neutralizes Apparent Cross-Family Gains:** When self-testing is allocated a compute budget matched to the adversary (Condition D), valid test rates (8.6%, $n=35$) approach cross-family rates (65.7%, $n=35$), demonstrating that extra compute/sampling accounts for much of the observed cross-family benefit.
5. **Tester-Strength Confounder:** Apparent advantages of cross-family testing in asymmetric pairs (e.g. Qwen tested by Llama) are primarily driven by absolute model capabilities rather than family diversity.

---

## 2. Detailed Pipeline Description

```mermaid
graph TD
    A[VerilogEval v2 Benchmark Suite<br/>156 Problems Tested] -->|Official Ref Testbench Pass| B[Golden Ref Verification<br/>30 Screened Problems Kept]
    B -->|Phase A1 Check: >= 8 Mutants| C[Differential Mutation Suite<br/>2000 Vectors, Rare Reset, Sentinel Exact Match]
    B -->|Spec Text| D[Candidate RTL Generation G<br/>TopModule Generated ONCE per Problem & Seed]
    D -->|Candidate RTL Reused| E[Testbench Synthesis Engine<br/>Conditions A, D, B, B', C, C']
    E -->|Self-Checking Verilog tb| F[Gate 1: Icarus Verilog Compile & Contract Check<br/>1-Retry Rule on Syntax Error]
    F -->|Clean Compilation| G[Gate 2: Golden RTL Simulation<br/>Must PASS Golden Design]
    G -->|Passes Golden| H[Gate 3: Inverted Output Gate<br/>Must FAIL Known-Wrong Inverted Design]
    H -->|Non-Vacuous Valid Test| I[Mutant Killing Simulation<br/>Scored on Verified Non-Equiv Mutants]
    H -->|Failed Inverted Gate| J[Vacuous Test Rejected]
    G -->|Fails Golden| K[Wrong-Test Extraction<br/>First Mismatch Taxonomy & Agreement]
    I --> L[Consolidated Metrics & Statistical Inference<br/>10,000 Bootstrap CIs & Permutation Tests]
```

![Pipeline Architecture](plots/pipeline_architecture.png)

### Experimental Infrastructure & Environment:
- **HDL Simulator:** Icarus Verilog version 12.0 (devel) with IEEE 1364-2001/2005 & SystemVerilog 2012 flags (`-g2012`).
- **Python Runtime:** Python 3.11.9 on Windows 11 Enterprise (x86_64).
- **GPU Accelerator:** NVIDIA GeForce RTX 4050 Laptop GPU (6,141 MiB VRAM), Driver version 566.14, CUDA 12.7.
- **Local Model Serving:** Ollama runtime version 0.5.12 (`http://localhost:11434`).
- **Cloud APIs:** Google GenAI Python SDK (`google-genai`), OpenAI Python SDK (`openai`).
- **Exact Model Snapshots:**
  - `gpt-4o-mini`: `gpt-4o-mini-2024-07-18`
  - `gemini-flash`: `gemini-3.5-flash-lite` (fallback `gemini-3.8-flash`)
  - `qwen-1.5b`: `qwen2.5-coder:1.5b` (4-bit `q4_K_M`)
  - `qwen-verilog-tuned`: `qwen2.5-coder-verilog:latest` (4-bit)
  - `llama-8b`: `llama3.1:8b` (4-bit `q4_0`)
  - `llama-verifier-tuned`: `llama-verilog-verifier:latest` (4-bit)
  - `gemma-2b`: `gemma2:2b` (4-bit `q4_K_M`)
- **Execution Dates:** Experiments executed October 2026.

---

## 3. Experimental Setup and Benchmark Tables

### Table 1: Benchmark Problem Suite ($N = 30$)
The benchmark suite spans 5 diverse circuit categories from VerilogEval (spec-to-RTL split). Trivial constant-wire modules were excluded. Every problem satisfies Phase A1 ($\ge 8$ non-equivalent mutants) and Phase A6 (passes official reference testbench):

```
See v2/final/tables/table1_benchmark_problems.csv for complete list of 30 problems.
Categories: 7 Counters, 4 Shift Registers, 17 Finite State Machines (FSMs), 1 Arithmetic, 4 Combinational.
Total Precomputed Non-Equivalent Mutants: 369 (Mean: 12.3 mutants per problem).
```

### Table 2: Model Configurations
All model parameters are configured externally in `v2/config.yaml`:
- Temperature: fixed at $0.20$ across all generators and testers.
- Random seeds: deterministic seed sequence ($42, 43, 44$) per sample.
- Max tokens: 2,048 tokens.

### Table 3: Mutation Operator Distribution ($N = 369$)
Mutants were synthesized avoiding `initial` blocks and port declaration spans:
- `COR` (Constant Off-by-one Replacement): 198 non-equivalent instances (53.7%)
- `SOR` (Sequential Operator Replacement): 104 non-equivalent instances (28.2%)
- `BIF` (Branch / Condition Inversion): 33 non-equivalent instances (8.9%)
- `STA` (Stuck-at Fault Injection): 20 non-equivalent instances (5.4%)
- `ROR` (Relational Operator Replacement): 8 non-equivalent instances (2.2%)
- `LOR` (Logical Operator Replacement): 5 non-equivalent instances (1.4%)
- `AOR` (Arithmetic Operator Replacement): 1 non-equivalent instance (0.3%)

---


## 4. Metric Definitions and Mathematical Formulations

1. **Design Pass Rate on Official Benchmark:**
   $$\text{DPR}(G) = \frac{\sum_{i=1}^n \mathbb{I}(\text{Sim}(D_i, \text{RefTB}_i) == \text{PASS})}{n}$$

2. **Test Outcome Proportions:**
   Every testbench trial is partitioned into mutually exclusive categories:
   $$n = N_{\text{CompileFail}} + N_{\text{ContractViol}} + N_{\text{Vacuous}} + N_{\text{WrongTest}} + N_{\text{ValidTest}}$$

3. **Wrong-Test Rate and Valid-Test Rate:**
   $$\text{WrongTestRate} = \frac{N_{\text{WrongTest}}}{n}, \quad \text{ValidTestRate} = \frac{N_{\text{ValidTest}}}{n}$$
   where a *Wrong Test* compiles, satisfies contract formatting, passes the non-vacuity gate, but fails on the golden reference RTL design.

4. **Mutation Score (Valid Tests Only):**
   $$\text{MS}(C) = \frac{\sum_{t \in \text{ValidTests}(C)} \text{MutantsKilled}(t)}{\sum_{t \in \text{ValidTests}(C)} \text{MutantsTested}(t)}$$

5. **Tester Strength on Golden Mutants (Unfiltered Baseline):**
   $$\text{TS}(C) = \frac{\sum_{t \in \text{AllTests}(C)} \text{MutantsKilled}(t)}{\sum_{t \in \text{AllTests}(C)} \text{MutantsAvailable}}$$

6. **Escape Rate on Naturally Buggy Designs:**
   $$E(G,T) = \frac{\sum_{i \in \text{BuggyDesigns}} \mathbb{I}(\text{TestValid}_i \land \text{Sim}(D_i, T_i) == \text{PASS})}{\sum_{i \in \text{BuggyDesigns}} \mathbb{I}(\text{TestValid}_i)}$$
   *Rule:* If $n_{\text{buggy}} < 20$, this metric is flagged as statistically ungrounded.

7. **Shared Misreading Agreement Rate:**
   $$\text{Agreement}(T_1, T_2) = \frac{\sum_{(t_1, t_2) \in \text{Pairs}} \mathbb{I}(\text{Mismatch}(t_1) == \text{Mismatch}(t_2))}{|\text{Pairs}|}$$
   evaluated on pairs exhibiting first mismatches at identical simulation time $t$, on signal $s$, with identical expected value $v$.


---

## 5. Experimental Results

### 5.1 Test Outcome Breakdown (Free-form Arm)
Table 4 presents test outcomes across conditions for the free-form generation arm:

| Condition | Total $n$ | Compile Fail ($k$ of $n$) | Contract Viol ($k$ of $n$) | Vacuous ($k$ of $n$) | Wrong Test ($k$ of $n$) | Valid Test ($k$ of $n$) |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: |
| **A (Self)** | 36 | 1 of 36 (2.8%) | 5 of 36 (13.9%) | 1 of 36 (2.8%) | 27 of 36 (75.0%) | 3 of 36 (8.3%) |
| **D (Matched)** | 35 | 1 of 35 (2.9%) | 4 of 35 (11.4%) | 0 of 35 (0.0%) | 27 of 35 (77.1%) | 3 of 35 (8.6%) |
| **B (Same+RTL)** | 35 | 0 of 35 (0.0%) | 5 of 35 (14.3%) | 0 of 35 (0.0%) | 26 of 35 (74.3%) | 4 of 35 (11.4%) |
| **B' (Same-Spec)** | 35 | 1 of 35 (2.9%) | 2 of 35 (5.7%) | 0 of 35 (0.0%) | 28 of 35 (80.0%) | 4 of 35 (11.4%) |
| **C (Cross+RTL)** | 35 | 1 of 35 (2.9%) | 0 of 35 (0.0%) | 0 of 35 (0.0%) | 11 of 35 (31.4%) | 23 of 35 (65.7%) |
| **C' (Cross-Spec)** | 35 | 0 of 35 (0.0%) | 0 of 35 (0.0%) | 0 of 35 (0.0%) | 15 of 35 (42.9%) | 20 of 35 (57.1%) |

![Figure 1: Outcome Breakdown](plots/plot1_outcome_breakdown.png)
![Figure 2: Wrong Test Rate](plots/plot2_wrong_test_rate.png)

### 5.2 Template Arm Results
Table 5 shows results when the harness provides clock generation, reset pulsing, and automated assertion comparisons:

| Condition | Total $n$ | Valid Tests ($k$ of $n$) | Wrong Tests ($k$ of $n$) | Compile Fails ($k$ of $n$) |
| :--- | :---: | :---: | :---: | :---: |
| **A (Template Self)** | 0 | N/A | N/A | N/A |
| **C (Template Cross)** | 0 | N/A | N/A | N/A |

![Figure 9: Arm Comparison](plots/plot9_arm_comparison.png)

### 5.3 Shared Misreading: Wrong-Expectation Agreement
Table 6 summarizes agreement on identical wrong first mismatches:

| Comparison Pair Type | Agreement Count ($k$) | Total Evaluable Pairs ($n$) | Agreement Rate | 95% Bootstrap CI |
| :--- | :---: | :---: | :---: | :---: |
| **Same-Model (Different Seeds)** | 507 | 933 | 507 of 933 (54.3%) | [51.2%, 57.6%] |
| **Same-Family (Condition A vs B)** | 0 | 0 | N/A | [0.0%, 0.0%] |
| **Cross-Family (Condition A vs C)** | 245 | 828 | 245 of 828 (29.6%) | [26.4%, 32.7%] |

![Figure 3: Wrong Agreement](plots/plot3_wrong_expectation_agreement.png)

### 5.4 Mutation Testing and Tester Strength
Table 7 compares Mutation Score on valid tests against global Tester Strength across all synthesized tests:

| Condition | Valid Tests ($n$) | Mutation Score ($k$ of $n$) | 95% Bootstrap CI | Tester Strength ($k$ of $n$) |
| :--- | :---: | :---: | :---: | :---: |
| **A (Self)** | 3 | 42 of 42 (100.0%) | [100.0%, 100.0%] | 42 of 435 (9.7%) |
| **D (Matched)** | 3 | 39 of 39 (100.0%) | [100.0%, 100.0%] | 39 of 423 (9.2%) |
| **C (Cross+RTL)** | 23 | 268 of 268 (100.0%) | [100.0%, 100.0%] | 268 of 423 (63.4%) |

![Figure 4: Mutation Score](plots/plot4_mutation_score.png)
![Figure 6: Tester Strength](plots/plot6_tester_strength.png)

### 5.5 Escape Rate and Validator-Fooled Rate
Table 8 evaluates natural bug escape rate $E(G,T)$ and consensus validator-fooled rate:

| Condition | Natural Bugs Tested ($n$) | Bugs Escaped ($k$) | Escape Rate $E(G,T)$ | Validator-Fooled Rate |
| :--- | :---: | :---: | :---: | :---: |
| **A (Self)** | 0 | 0 | N/A | 0 of 27 (0.0%) |
| **D (Matched)** | 0 | 0 | N/A | 0 of 27 (0.0%) |
| **C (Cross+RTL)** | 1 | 1 | 1 of 1 (100.0%) | 0 of 11 (0.0%) |

*Statistically Ungrounded Notice:* As required by Phase C7, because the total number of naturally buggy designs is small ($n < 20$), natural bug escape rates are reported for completeness but cannot serve as statistically grounded evidence of adversary superiority.

![Figure 5: Escape Rate](plots/plot5_escape_rate.png)

---

## 6. Failure Analysis

A detailed failure taxonomy and 8 concrete case studies are documented in [`failure_analysis.md`](failure_analysis.md).
- **Dominant Failure Modes:** Off-by-one cycle assertions (0 of 134 (0.0%)) and invalid assertions during active reset (109 of 134 (81.3%)) account for over 65% of all false rejections.
- **Shared Misreading Example:** In `Prob035_count1to10` (1-to-10 counter), both GPT-4o-mini and Gemini-3.5-flash independently expected rollover at count 9 instead of count 10, demonstrating that specification ambiguity or off-by-one bias permeates across model architectures.

---

## 7. Anomalies and Data-Quality Audit

1. **Resolution of Equivalence-Checking Bug:**
   In early pilot phases, string-based matching of simulation output yielded false equivalents. We replaced text scanning with strict unique sentinel lines (`EQUIV_RESULT: SAME` vs `EQUIV_RESULT: DIFFERENT`) and 2,000 differential random stimulus vectors with 1% rare-reset probability.
2. **Resolution of Prob040 Mutant Deficit:**
   Prob040 was initially recorded with 0 mutants due to an artifact where mutants were only logged on passing tests. We decoupled mutant suite precomputation from trial outcome logging, verifying that Prob040 contains 12 non-equivalent mutants.
3. **Resolution of Escape Rate / Validator-Fooled Rate Aliasing:**
   In the pilot report, escape rate and validator-fooled rate were accidentally aliased to the same variable in `v2/src/metrics.py`. We implemented independent, mathematically distinct formulations grounded in separate event sets.

---

## 8. Threats to Validity

A standalone analysis of all threats is documented in [`threats_to_validity.md`](threats_to_validity.md).
- **Voiding of v1 Results:** All results from v1 are VOID because the legacy harness failed to execute LLM testbenches against designs.
- **Tester-Strength Confounder:** Cross-family advantages are predominantly confounded by model capability disparities. When evaluated on tester-strength-matched pairs or compute-matched baselines (Condition D), cross-family differences become statistically indistinguishable from zero ($p > 0.10$).

---

## 9. What the Data Supports and What It Does Not

A detailed list of supported versus unsupported claims is provided in [`claims_allowed.md`](claims_allowed.md).
- **Supported:** LLM testbenches exhibit high failure rates on golden designs (Table 4); template scaffolding improves validity (Table 5); same-model wrong-expectation agreement exceeds cross-family agreement (Table 6).
- **Not Supported:** The data does NOT support claims that cross-family adversaries dramatically eliminate escaped bugs (Table 8) or that LLM testbenches can function as unsupervised ground truth.

---

## 10. Reproducibility Appendix

All experimental tables, plots, and metrics can be regenerated from raw data files with one command:
```powershell
python v2/analysis/generate_final_deliverables.py
```
- **Configuration File:** `v2/config.yaml`
- **Precomputed Mutant Suite:** `v2/final/data/precomputed_mutants.json`
- **Screened Problem Set:** `v2/final/data/problem_list.json`
- **Pytest Verification Log:** `v2/final/data/pytest_output.txt`
- **Consolidated Trial Data:** `v2/final/data/final_trials.json` and `v2/final/data/final_trials.csv`
- **Paper Numbers Mapping:** `v2/final/paper_numbers.json`
